'use client';

import styles from '@/styles/Projects.module.css';

interface Project {
  title: string;
  category: string;
  description: string;
  features: string[];
  tech: string[];
  githubUrl: string;
  liveUrl: string | null;
}

const projects: Project[] = [
  {
    title: 'ML-Powered Analytics Dashboard',
    category: 'Data & ML',
    description:
      'A real-time analytics platform that processes millions of events and surfaces anomalies using machine learning.',
    features: [
      'Real-time event processing pipeline',
      'Anomaly detection with 94% accuracy',
      'Interactive charts and customizable widgets',
    ],
    tech: ['Python', 'React', 'Next.js', 'TensorFlow', 'PostgreSQL'],
    githubUrl: 'https://github.com/',
    liveUrl: null,
  },
  {
    title: 'Secure Auth System',
    category: 'Cybersecurity',
    description:
      'A production-grade authentication system with multi-factor support, rate limiting, and threat detection.',
    features: [
      'JWT + refresh token rotation',
      'TOTP-based two-factor authentication',
      'Brute-force protection and audit logging',
    ],
    tech: ['Next.js', 'TypeScript', 'Node.js', 'Redis'],
    githubUrl: 'https://github.com/',
    liveUrl: 'https://example.com',
  },
  {
    title: 'Data Pipeline Orchestrator',
    category: 'Data Engineering',
    description:
      'A scalable ETL orchestration tool for managing complex data workflows with monitoring and alerting.',
    features: [
      'DAG-based task scheduling',
      'Automated retry and error handling',
      'Real-time pipeline monitoring dashboard',
    ],
    tech: ['Python', 'Docker', 'PostgreSQL', 'React'],
    githubUrl: 'https://github.com/',
    liveUrl: null,
  },
  {
    title: 'Vulnerability Scanner',
    category: 'Cybersecurity',
    description:
      'An automated security scanner that identifies common web vulnerabilities based on the OWASP Top 10.',
    features: [
      'Automated XSS and SQL injection detection',
      'Detailed vulnerability reports with remediation steps',
      'CI/CD integration for continuous scanning',
    ],
    tech: ['Python', 'Flask', 'Docker', 'JavaScript'],
    githubUrl: 'https://github.com/',
    liveUrl: null,
  },
  {
    title: 'AI Content Summarizer',
    category: 'Machine Learning',
    description:
      'A web app that uses NLP models to summarize long-form content into concise, readable summaries.',
    features: [
      'Abstractive summarization with transformer models',
      'Adjustable summary length and style',
      'Export to multiple formats',
    ],
    tech: ['Python', 'PyTorch', 'Next.js', 'FastAPI'],
    githubUrl: 'https://github.com/',
    liveUrl: 'https://example.com',
  },
  {
    title: 'Portfolio Website',
    category: 'Web Development',
    description:
      'A fully responsive portfolio built with Next.js, featuring dark/light mode and modular CSS architecture.',
    features: [
      'Light/dark theme with system preference detection',
      'Component-based CSS modules — no utility framework',
      'Optimized for performance and accessibility',
    ],
    tech: ['Next.js', 'React', 'TypeScript', 'CSS Modules'],
    githubUrl: 'https://github.com/',
    liveUrl: null,
  },
];

export default function Projects() {
  return (
    <section id="projects" className={styles.projects}>
      <div className="container">
        <h2 className="section-title">Featured Projects</h2>
        <p className="section-subtitle">
          A selection of projects across web, data, ML, and security
        </p>
        <div className="section-divider" />

        <div className={styles.projectsGrid}>
          {projects.map((project) => (
            <div key={project.title} className={styles.projectCard}>
              <div className={styles.projectTop}>
                <span className={styles.projectCategory}>
                  {project.category}
                </span>
                <div className={styles.projectLinks}>
                  <a
                    href={project.githubUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={styles.projectLink}
                    aria-label="GitHub repository"
                  >
                    <svg
                      width="18"
                      height="18"
                      viewBox="0 0 24 24"
                      fill="currentColor"
                    >
                      <path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0024 12c0-6.63-5.37-12-12-12z" />
                    </svg>
                  </a>
                  {project.liveUrl && (
                    <a
                      href={project.liveUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={styles.projectLink}
                      aria-label="Live demo"
                    >
                      <svg
                        width="18"
                        height="18"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      >
                        <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
                        <polyline points="15 3 21 3 21 9" />
                        <line x1="10" y1="14" x2="21" y2="3" />
                      </svg>
                    </a>
                  )}
                </div>
              </div>

              <h3 className={styles.projectTitle}>{project.title}</h3>
              <p className={styles.projectDescription}>
                {project.description}
              </p>

              <ul className={styles.featureList}>
                {project.features.map((feature) => (
                  <li key={feature} className={styles.feature}>
                    {feature}
                  </li>
                ))}
              </ul>

              <div className={styles.techTags}>
                {project.tech.map((tech) => (
                  <span key={tech} className={styles.techTag}>
                    {tech}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
